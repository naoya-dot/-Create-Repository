# みんなの予定 — 共有スケジュール＋LINE通知

## できること

- メールのリンクでログイン
- 共有グループの作成
- 招待コードによるメンバー参加
- 予定の登録・共有・削除
- 予定の開始時刻、10分前、30分前、1時間前、1日前にLINE通知
- LINE公式アカウントへ6桁コードを送ってアカウント連携

## 重要

このファイルだけではLINE通知は始まりません。  
Supabase、LINE公式アカウント、Vercelの無料または有料アカウントを設定し、環境変数を登録します。

Vercel HobbyではCronの実行頻度に制限があるため、1分単位の正確な通知にはVercel Pro等が必要です。
無料運用を優先する場合は、Supabase Cronなど別の定期実行基盤へ置き換えてください。

## 1. Supabase

1. Supabaseで新規プロジェクトを作成
2. SQL Editorを開く
3. `supabase/schema.sql` を貼り付けて実行
4. Project Settings → APIでURL、anon key、service role keyを確認
5. Authentication → URL Configurationへ公開URLを追加

## 2. LINE

1. LINE公式アカウントを作成
2. LINE DevelopersでMessaging APIチャネルを作成
3. Channel secretと長期Channel access tokenを取得
4. Webhook URLを次の形式で登録  
   `https://あなたのURL/api/line/webhook`
5. Webhookを有効化
6. 応答メッセージは必要に応じて無効化
7. 利用者に公式アカウントを友だち追加してもらう

## 3. Vercel

1. このフォルダーをGitHubへアップロード
2. VercelでImport
3. Environment Variablesへ以下を登録

- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`
- `LINE_CHANNEL_ACCESS_TOKEN`
- `LINE_CHANNEL_SECRET`
- `CRON_SECRET`（十分長いランダム文字列）
- `NEXT_PUBLIC_APP_URL`（Vercelの公開URL）

4. デプロイ

## 4. ローカル確認

```bash
cp .env.example .env.local
npm install
npm run dev
```

ブラウザで `http://localhost:3000` を開きます。

## 利用手順

1. メールアドレスでログイン
2. 共有グループを作る
3. 招待コードを相手へ送る
4. 相手もログインして招待コードで参加
5. 「LINE通知をつなぐ」で6桁コードを発行
6. コードをLINE公式アカウントへ送信
7. 予定を登録

## 本番利用前に追加推奨

- 予定の編集
- 複数グループ切替
- グループ管理者だけが予定を削除できる権限
- 通知の再送・失敗記録
- タイムゾーン設定
- プライバシーポリシー
- 利用規約
- LINEの送信上限・料金の監視
