create extension if not exists pgcrypto;

create table public.groups (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  invite_code text not null unique,
  owner_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table public.memberships (
  group_id uuid not null references public.groups(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'member' check (role in ('owner','member')),
  created_at timestamptz not null default now(),
  primary key (group_id, user_id)
);

create table public.events (
  id uuid primary key default gen_random_uuid(),
  group_id uuid not null references public.groups(id) on delete cascade,
  title text not null,
  starts_at timestamptz not null,
  location text,
  details text,
  notify_minutes_before integer not null default 30,
  created_by uuid not null references auth.users(id) on delete cascade,
  notified boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.line_link_codes (
  user_id uuid primary key references auth.users(id) on delete cascade,
  code text not null unique,
  expires_at timestamptz not null
);

create table public.line_links (
  user_id uuid primary key references auth.users(id) on delete cascade,
  line_user_id text not null unique,
  created_at timestamptz not null default now()
);

create or replace function public.is_group_member(target_group uuid)
returns boolean
language sql
security definer
set search_path = public
stable
as $$
  select exists (
    select 1
    from public.memberships
    where group_id = target_group and user_id = auth.uid()
  );
$$;

grant execute on function public.is_group_member(uuid) to authenticated;

alter table public.groups enable row level security;
alter table public.memberships enable row level security;
alter table public.events enable row level security;
alter table public.line_link_codes enable row level security;
alter table public.line_links enable row level security;

create policy "groups visible to members"
on public.groups for select
using (owner_id = auth.uid() or public.is_group_member(id));

create policy "users create groups"
on public.groups for insert
with check (owner_id = auth.uid());

create policy "memberships visible to members"
on public.memberships for select
using (user_id = auth.uid() or public.is_group_member(group_id));

create policy "users join groups"
on public.memberships for insert
with check (user_id = auth.uid());

create policy "events visible to members"
on public.events for select
using (public.is_group_member(group_id));

create policy "members create events"
on public.events for insert
with check (created_by = auth.uid() and public.is_group_member(group_id));

create policy "members delete events"
on public.events for delete
using (public.is_group_member(group_id));

create policy "own line code"
on public.line_link_codes for all
using (user_id = auth.uid())
with check (user_id = auth.uid());

create policy "own line link"
on public.line_links for select
using (user_id = auth.uid());
