"use client";

import { useEffect, useMemo, useState } from "react";
import { createClient } from "../lib/supabase-browser";

const emptyEvent = {
  title: "",
  starts_at: "",
  location: "",
  details: "",
  notify_minutes_before: 30
};

export default function Home() {
  const supabase = useMemo(() => createClient(), []);
  const [session, setSession] = useState(null);
  const [email, setEmail] = useState("");
  const [group, setGroup] = useState(null);
  const [events, setEvents] = useState([]);
  const [form, setForm] = useState(emptyEvent);
  const [inviteCode, setInviteCode] = useState("");
  const [lineCode, setLineCode] = useState("");
  const [message, setMessage] = useState("");

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => setSession(next));
    return () => listener.subscription.unsubscribe();
  }, [supabase]);

  useEffect(() => {
    if (session) loadData();
  }, [session]);

  async function loadData() {
    setMessage("");
    const { data: memberships, error } = await supabase
      .from("memberships")
      .select("group_id, groups(id,name,invite_code)")
      .limit(1);

    if (error) return setMessage(error.message);
    const selected = memberships?.[0]?.groups || null;
    setGroup(selected);

    if (selected) {
      const { data, error: eventError } = await supabase
        .from("events")
        .select("*")
        .eq("group_id", selected.id)
        .order("starts_at", { ascending: true });
      if (eventError) setMessage(eventError.message);
      setEvents(data || []);
    }
  }

  async function login(e) {
    e.preventDefault();
    setMessage("");
    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: { emailRedirectTo: window.location.origin }
    });
    setMessage(error ? error.message : "ログイン用メールを送りました。メール内のリンクを開いてください。");
  }

  async function createGroup() {
    const name = prompt("共有グループ名を入力してください", "社内予定");
    if (!name) return;
    const code = crypto.randomUUID().slice(0, 8).toUpperCase();
    const { data, error } = await supabase
      .from("groups")
      .insert({ name, invite_code: code, owner_id: session.user.id })
      .select()
      .single();
    if (error) return setMessage(error.message);

    const { error: memberError } = await supabase
      .from("memberships")
      .insert({ group_id: data.id, user_id: session.user.id, role: "owner" });
    if (memberError) return setMessage(memberError.message);
    await loadData();
  }

  async function joinGroup() {
    const { data: found, error } = await supabase
      .from("groups")
      .select("id")
      .eq("invite_code", inviteCode.trim().toUpperCase())
      .single();
    if (error || !found) return setMessage("招待コードが見つかりません。");

    const { error: joinError } = await supabase
      .from("memberships")
      .insert({ group_id: found.id, user_id: session.user.id, role: "member" });
    if (joinError) return setMessage(joinError.message);
    setInviteCode("");
    await loadData();
  }

  async function saveEvent(e) {
    e.preventDefault();
    if (!group) return;
    const { error } = await supabase.from("events").insert({
      ...form,
      group_id: group.id,
      created_by: session.user.id,
      starts_at: new Date(form.starts_at).toISOString()
    });
    if (error) return setMessage(error.message);
    setForm(emptyEvent);
    await loadData();
  }

  async function removeEvent(id) {
    if (!confirm("この予定を削除しますか？")) return;
    const { error } = await supabase.from("events").delete().eq("id", id);
    if (error) return setMessage(error.message);
    await loadData();
  }

  async function issueLineCode() {
    const code = String(Math.floor(100000 + Math.random() * 900000));
    const expires = new Date(Date.now() + 10 * 60 * 1000).toISOString();
    const { error } = await supabase.from("line_link_codes").upsert({
      user_id: session.user.id,
      code,
      expires_at: expires
    }, { onConflict: "user_id" });
    if (error) return setMessage(error.message);
    setLineCode(code);
  }

  if (!session) {
    return (
      <main>
        <div className="card">
          <h1>みんなの予定</h1>
          <p>予定を共有し、時間になったらLINEでお知らせします。</p>
          <form onSubmit={login}>
            <label>メールアドレス</label>
            <input type="email" required value={email} onChange={e => setEmail(e.target.value)} />
            <br /><br />
            <button>ログイン用メールを送る</button>
          </form>
          {message && <p className="notice">{message}</p>}
        </div>
      </main>
    );
  }

  return (
    <main>
      <header>
        <div>
          <h1>みんなの予定</h1>
          <small>{session.user.email}</small>
        </div>
        <button className="secondary" onClick={() => supabase.auth.signOut()}>ログアウト</button>
      </header>

      {message && <div className="notice error">{message}</div>}

      {!group ? (
        <div className="card">
          <h2>共有グループを準備する</h2>
          <div className="actions">
            <button onClick={createGroup}>新しいグループを作る</button>
          </div>
          <hr />
          <label>招待コード</label>
          <div className="actions">
            <input value={inviteCode} onChange={e => setInviteCode(e.target.value)} />
            <button onClick={joinGroup}>参加する</button>
          </div>
        </div>
      ) : (
        <>
          <div className="card">
            <h2>{group.name}</h2>
            <p>招待コード：<strong>{group.invite_code}</strong></p>
            <small>このコードを共有相手へ伝えてください。</small>
          </div>

          <div className="card">
            <h2>LINE通知をつなぐ</h2>
            <p>下のボタンで6桁コードを発行し、10分以内にLINE公式アカウントへ送信します。</p>
            <button onClick={issueLineCode}>連携コードを発行</button>
            {lineCode && <p className="notice">LINEへ送るコード：<strong>{lineCode}</strong></p>}
          </div>

          <form className="card" onSubmit={saveEvent}>
            <h2>予定を登録</h2>
            <div className="grid">
              <div>
                <label>予定名</label>
                <input required value={form.title} onChange={e => setForm({...form, title:e.target.value})} />
              </div>
              <div>
                <label>日時</label>
                <input type="datetime-local" required value={form.starts_at}
                  onChange={e => setForm({...form, starts_at:e.target.value})} />
              </div>
              <div>
                <label>場所</label>
                <input value={form.location} onChange={e => setForm({...form, location:e.target.value})} />
              </div>
              <div>
                <label>何分前に通知するか</label>
                <select value={form.notify_minutes_before}
                  onChange={e => setForm({...form, notify_minutes_before:Number(e.target.value)})}>
                  <option value="0">開始時刻</option>
                  <option value="10">10分前</option>
                  <option value="30">30分前</option>
                  <option value="60">1時間前</option>
                  <option value="1440">1日前</option>
                </select>
              </div>
              <div className="full">
                <label>詳細</label>
                <textarea value={form.details} onChange={e => setForm({...form, details:e.target.value})} />
              </div>
              <div className="full"><button>予定を登録</button></div>
            </div>
          </form>

          <div className="card">
            <h2>予定一覧</h2>
            {events.length === 0 && <p>まだ予定がありません。</p>}
            {events.map(event => (
              <div className="event" key={event.id}>
                <div>
                  <div className="event-title">{event.title}</div>
                  <div className="meta">
                    {new Date(event.starts_at).toLocaleString("ja-JP")}
                    {event.location ? ` ／ ${event.location}` : ""}
                  </div>
                  {event.details && <p>{event.details}</p>}
                </div>
                <div className="actions">
                  <button className="danger" onClick={() => removeEvent(event.id)}>削除</button>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </main>
  );
}
