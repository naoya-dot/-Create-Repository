import "./globals.css";

export const metadata = {
  title: "みんなの予定",
  description: "予定を共有してLINEで通知するスケジュール管理アプリ"
};

export default function RootLayout({ children }) {
  return (
    <html lang="ja">
      <body>{children}</body>
    </html>
  );
}
