import { createAdminClient } from "../../../../lib/supabase-admin";

async function push(lineUserId, text) {
  const response = await fetch("https://api.line.me/v2/bot/message/push", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${process.env.LINE_CHANNEL_ACCESS_TOKEN}`
    },
    body: JSON.stringify({
      to: lineUserId,
      messages: [{ type: "text", text }]
    })
  });
  if (!response.ok) throw new Error(await response.text());
}

export async function GET(request) {
  const auth = request.headers.get("authorization");
  if (auth !== `Bearer ${process.env.CRON_SECRET}`) {
    return new Response("Unauthorized", { status: 401 });
  }

  const supabase = createAdminClient();
  const now = new Date();
  const from = new Date(now.getTime() - 70 * 1000).toISOString();
  const to = new Date(now.getTime() + 25 * 60 * 60 * 1000).toISOString();

  const { data: events, error } = await supabase
    .from("events")
    .select("*, groups(name)")
    .gte("starts_at", from)
    .lte("starts_at", to)
    .eq("notified", false);

  if (error) return Response.json({ error: error.message }, { status: 500 });

  let sent = 0;
  for (const event of events || []) {
    const notifyAt = new Date(
      new Date(event.starts_at).getTime() - event.notify_minutes_before * 60000
    );
    if (notifyAt > now || now.getTime() - notifyAt.getTime() > 70000) continue;

    const { data: members, error: memberError } = await supabase
      .from("memberships")
      .select("user_id")
      .eq("group_id", event.group_id);
    if (memberError) continue;

    const userIds = (members || []).map(m => m.user_id);
    if (userIds.length === 0) continue;

    const { data: links } = await supabase
      .from("line_links")
      .select("line_user_id")
      .in("user_id", userIds);

    const start = new Date(event.starts_at).toLocaleString("ja-JP", {
      timeZone: "Asia/Tokyo"
    });
    const text = [
      "【予定のお知らせ】",
      event.title,
      `日時：${start}`,
      event.location ? `場所：${event.location}` : null,
      event.details || null,
      process.env.NEXT_PUBLIC_APP_URL
    ].filter(Boolean).join("\n");

    let allSucceeded = true;
    for (const link of links || []) {
      try {
        await push(link.line_user_id, text);
        sent++;
      } catch {
        allSucceeded = false;
      }
    }

    if (allSucceeded) {
      await supabase.from("events").update({ notified: true }).eq("id", event.id);
    }
  }

  return Response.json({ ok: true, sent });
}
