import crypto from "crypto";
import { createAdminClient } from "../../../../lib/supabase-admin";

function validSignature(raw, signature) {
  const digest = crypto
    .createHmac("SHA256", process.env.LINE_CHANNEL_SECRET)
    .update(raw)
    .digest("base64");
  return crypto.timingSafeEqual(Buffer.from(digest), Buffer.from(signature || ""));
}

async function reply(replyToken, text) {
  await fetch("https://api.line.me/v2/bot/message/reply", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${process.env.LINE_CHANNEL_ACCESS_TOKEN}`
    },
    body: JSON.stringify({
      replyToken,
      messages: [{ type: "text", text }]
    })
  });
}

export async function POST(request) {
  const raw = await request.text();
  if (!validSignature(raw, request.headers.get("x-line-signature"))) {
    return new Response("Invalid signature", { status: 401 });
  }

  const payload = JSON.parse(raw);
  const supabase = createAdminClient();

  for (const event of payload.events || []) {
    if (event.type !== "message" || event.message?.type !== "text") continue;
    const code = event.message.text.trim();
    if (!/^\d{6}$/.test(code)) continue;

    const { data: linkCode } = await supabase
      .from("line_link_codes")
      .select("*")
      .eq("code", code)
      .gt("expires_at", new Date().toISOString())
      .maybeSingle();

    if (!linkCode) {
      await reply(event.replyToken, "コードが無効または期限切れです。アプリで新しいコードを発行してください。");
      continue;
    }

    await supabase.from("line_links").upsert({
      user_id: linkCode.user_id,
      line_user_id: event.source.userId
    }, { onConflict: "user_id" });

    await supabase.from("line_link_codes").delete().eq("user_id", linkCode.user_id);
    await reply(event.replyToken, "連携が完了しました。予定の通知をLINEで受け取れます。");
  }

  return Response.json({ ok: true });
}
